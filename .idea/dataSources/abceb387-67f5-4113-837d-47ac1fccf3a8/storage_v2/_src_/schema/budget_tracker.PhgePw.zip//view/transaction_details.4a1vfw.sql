create definer = root@localhost view transaction_details as
select `t`.`id`          AS `id`,
       `t`.`description` AS `description`,
       `t`.`amount`      AS `amount`,
       `t`.`type`        AS `type`,
       `t`.`date`        AS `date`,
       `c`.`name`        AS `category_name`
from (`budget_tracker`.`transactions` `t` left join `budget_tracker`.`categories` `c`
      on ((`t`.`category_id` = `c`.`id`)));

